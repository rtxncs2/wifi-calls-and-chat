# LAN Chat

A Telegram-style web app for text chat, voice calls and file sharing between devices on the same Wi-Fi. No accounts, no internet, no database.

- **Left:** chat list (Everyone + each person online), search, unread badges.
- **Right:** the conversation. Your messages are on the right, received messages on the left. Use the phone icon in the header to start a voice call.
- On a phone the list and the chat are separate screens (use the back arrow).

## Requirements

- Node.js 18 or newer (Debian: `sudo apt install nodejs npm`)

## Run

```bash
cd lan-chat
npm install
npm start
```

The terminal prints the addresses and a QR code. Example:

```
https://192.168.1.25:3000   (voice + text)
http://192.168.1.25:3001    (text only)
```

On other devices (same Wi-Fi) open the `https://` address, or scan the QR code. The browser warns about the certificate: choose **Advanced -> Proceed**. This is expected, the app makes its own certificate.

Voice calls need the `https://` address (browsers block the microphone on plain HTTP). The `http://` address works for text only and is useful for testing.

## If the phone cannot open it

Do these in order:

1. **Use the right IP.** Use the Wi-Fi address printed by the server (usually `192.168.x.x`). Do not use `172.17.x.x` (Docker). `hostname -I` lists your addresses.
2. **Test the connection.** On the phone, open `http://YOUR-IP:3001/ping`. It must say "OK".
   - Says OK: the network is fine. If the `https://` page fails, see step 5.
   - Does not load: continue to step 3.
3. **Open the firewall** on the PC running the server:
   ```bash
   sudo ufw allow 3000/tcp
   sudo ufw allow 3001/tcp
   ```
   (If you use another firewall, allow these two TCP ports.)
4. **Same network.** The phone must be on the same Wi-Fi as the PC, not mobile data, not a "guest" network, and not a different band or router. Some routers block devices from talking to each other ("AP/client isolation"): turn it off in the router settings. If the PC is on a LAN cable, it must be the same router.
5. **Certificate on the phone.**
   - Android Chrome: **Advanced -> Proceed to ... (unsafe)**.
   - iPhone Safari: **Show Details -> visit this website**. If chat still says "Connection problem", use the `http://` address for text chat.
6. If your IP changed, just restart the server. It makes a new certificate automatically.

## Using it

1. Enter a name and tap **Start Messaging**. If someone already has that name, a number is added.
2. Tap **Everyone** for a group chat, or tap a person for a private chat.
3. Tap the **paperclip** next to the message box to send files (or drag and drop them onto the chat on a computer). Tap a file in the chat to download it.
4. Tap the phone icon to call. The other person sees an incoming call screen with Accept and Decline. In a call you can **Mute** or **End**.

To test alone, open the page in two browser tabs with different names.

## Sharing files

- Any file type can be shared (documents, photos, videos, audio, archives, apps…). Nothing is rejected by type.
- Works in a private chat and in **Everyone**. Works on both the `https://` and `http://` addresses.
- Files are streamed to the `uploads/` folder on the PC running the server. Uploads show a progress bar and can be cancelled with the X.
- Limit: 200 MB per file. Change it with `MAX_FILE_MB=500 npm start`.
- Files are deleted when the server restarts, and automatically after 24 hours (`FILE_KEEP_HOURS=48 npm start` to change).
- Downloads are always sent as a plain file download, so a shared file is never opened or run inside the chat page.

## Files

| File | Purpose |
|------|---------|
| `server.js` | HTTPS + HTTP server, chat relay, call signaling, file upload/download |
| `public/index.html` | The whole web app |
| `package.json` | Dependencies: `ws`, `selfsigned`, `qrcode-terminal` |
| `uploads/` | Shared files (created automatically, cleared on restart) |

## Options

- Different port: `PORT=4000 npm start` (the text-only port becomes 4001, or set `HTTP_PORT`).
- Max file size: `MAX_FILE_MB=500 npm start`.

## Notes

Calls are peer-to-peer (WebRTC) and chat goes through the server on your PC. Nothing leaves your local network. Message history is kept only in the open browser page and disappears when you close or refresh it. Shared files stay on the server PC (in `uploads/`) until restart or 24 hours.
