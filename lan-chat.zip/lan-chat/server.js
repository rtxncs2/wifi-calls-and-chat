// LAN Chat server
// - HTTPS on PORT (default 3000): full app, voice calls need this (microphone requires HTTPS)
// - HTTP  on HTTP_PORT (default 3001): same app, text chat only, handy to test phone connectivity
// - /ping on both ports: open it on your phone to check the Wi-Fi connection works
// - File sharing: files of any type are uploaded to ./uploads (POST /upload) and downloaded via /files/<id>

const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const selfsigned = require('selfsigned');
const { WebSocketServer } = require('ws');
let qr = null;
try { qr = require('qrcode-terminal'); } catch {}

const HTTPS_PORT = Number(process.env.PORT) || 3000;
const HTTP_PORT = Number(process.env.HTTP_PORT) || HTTPS_PORT + 1;

// ---------- file sharing settings ----------
const MAX_FILE_MB = Number(process.env.MAX_FILE_MB) || 200;           // per-file limit
const MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024;
const KEEP_HOURS = Number(process.env.FILE_KEEP_HOURS) || 24;          // shared files are deleted after this
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const files = new Map(); // id -> { id, path, name, size, owner, time }

function resetUploads() {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  for (const f of fs.readdirSync(UPLOAD_DIR)) { try { fs.unlinkSync(path.join(UPLOAD_DIR, f)); } catch {} }
}
resetUploads(); // start clean: the file list lives in memory, so old files could not be downloaded anyway
setInterval(() => {
  const limit = Date.now() - KEEP_HOURS * 3600 * 1000;
  for (const [id, f] of files) {
    if (f.time < limit) { files.delete(id); fs.unlink(f.path, () => {}); }
  }
}, 30 * 60 * 1000).unref();

// ---------- network addresses ----------
function allIPs() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const i of list || []) {
      if (i.family === 'IPv4' && !i.internal) out.push({ name, address: i.address });
    }
  }
  return out;
}

// Real Wi-Fi/LAN addresses first; hide Docker/VM/VPN interfaces that phones can't reach.
function lanIPs() {
  const skip = /^(docker|br-|veth|virbr|vmnet|vboxnet|tailscale|zt|tun|tap|wg)/i;
  const score = (ip) => (ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : 2);
  return allIPs()
    .filter((i) => !skip.test(i.name) && !i.address.startsWith('172.17.'))
    .sort((a, b) => score(a.address) - score(b.address));
}

// ---------- certificate (regenerated automatically if your IPs change) ----------
function getCert() {
  const dir = path.join(__dirname, 'cert');
  const keyFile = path.join(dir, 'key.pem');
  const certFile = path.join(dir, 'cert.pem');
  const ipFile = path.join(dir, 'ips.txt');
  const ipList = allIPs().map((i) => i.address).sort().join(',');

  if (fs.existsSync(keyFile) && fs.existsSync(certFile) && fs.existsSync(ipFile) &&
      fs.readFileSync(ipFile, 'utf8') === ipList) {
    return { key: fs.readFileSync(keyFile), cert: fs.readFileSync(certFile) };
  }
  const altNames = [
    { type: 2, value: 'localhost' },
    { type: 7, ip: '127.0.0.1' },
    ...allIPs().map((i) => ({ type: 7, ip: i.address })),
  ];
  const pems = selfsigned.generate([{ name: 'commonName', value: 'lan-chat' }], {
    days: 825,
    keySize: 2048,
    algorithm: 'sha256',
    extensions: [{ name: 'subjectAltName', altNames }],
  });
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(keyFile, pems.private);
  fs.writeFileSync(certFile, pems.cert);
  fs.writeFileSync(ipFile, ipList);
  return { key: pems.private, cert: pems.cert };
}

// ---------- web server ----------
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function cleanFileName(raw) {
  let n = '';
  try { n = decodeURIComponent(String(raw || '')); } catch { n = String(raw || ''); }
  n = path.basename(n.replace(/\\/g, '/')).replace(/[\u0000-\u001f<>:"|?*]/g, '_').trim().slice(0, 150);
  return n || 'file';
}

function handleUpload(req, res) {
  const me = clients.get(String(req.headers['x-client-id'] || ''));
  if (!me || !me.name) return json(res, 403, { error: 'Join the chat first' });

  const name = cleanFileName(req.headers['x-file-name']);

  const len = Number(req.headers['content-length']);
  if (!len) return json(res, 400, { error: 'The file is empty' });
  if (len > MAX_FILE_BYTES) return json(res, 413, { error: `File is too large (max ${MAX_FILE_MB} MB)` });

  const id = crypto.randomBytes(12).toString('hex');
  const dest = path.join(UPLOAD_DIR, id);
  const out = fs.createWriteStream(dest);
  let size = 0, failed = false;

  const fail = (code, msg) => {
    if (failed) return;
    failed = true;
    req.unpipe(out); out.destroy();
    fs.unlink(dest, () => {});
    if (!res.headersSent) json(res, code, { error: msg });
  };

  req.on('data', (chunk) => { size += chunk.length; if (size > MAX_FILE_BYTES) fail(413, `File is too large (max ${MAX_FILE_MB} MB)`); });
  req.on('aborted', () => fail(400, 'Upload cancelled'));
  req.on('error', () => fail(400, 'Upload failed'));
  out.on('error', () => fail(500, 'Could not save the file'));
  out.on('finish', () => {
    if (failed) return;
    files.set(id, { id, path: dest, name, size, owner: String(req.headers['x-client-id']), time: Date.now() });
    json(res, 200, { id, name, size });
  });
  req.pipe(out);
}

function handleDownload(id, res) {
  const f = files.get(id);
  if (!f || !fs.existsSync(f.path)) { res.writeHead(404); return res.end('This file is no longer available.'); }
  const ascii = f.name.replace(/[^\x20-\x7e]/g, '_').replace(/"/g, '');
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Length': f.size,
    'Content-Disposition': `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(f.name)}`,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
  });
  fs.createReadStream(f.path).pipe(res);
}

function handler(req, res) {
  const url = req.url.split('?')[0];
  let m;
  if (url === '/' || url === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    fs.createReadStream(path.join(__dirname, 'public', 'index.html')).pipe(res);
  } else if (url === '/ping') {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('OK - the LAN Chat server is reachable from this device.');
  } else if (url === '/config' && req.method === 'GET') {
    json(res, 200, { maxFileMB: MAX_FILE_MB });
  } else if (url === '/upload' && req.method === 'POST') {
    handleUpload(req, res);
  } else if (req.method === 'GET' && (m = url.match(/^\/files\/([a-f0-9]{24})$/))) {
    handleDownload(m[1], res);
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
}

const httpsServer = https.createServer(getCert(), handler);
const httpServer = http.createServer(handler);
httpsServer.requestTimeout = 0; httpServer.requestTimeout = 0; // big files on slow Wi-Fi must not time out

// ---------- chat + call signaling ----------
const wss = new WebSocketServer({ noServer: true });
for (const s of [httpsServer, httpServer]) {
  s.on('upgrade', (req, socket, head) => {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });
}

const clients = new Map(); // id -> { ws, name }
let nextId = 1;

function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function uniqueName(base, id) {
  let n = base, i = 2;
  const taken = () =>
    n.toLowerCase() === 'everyone' ||
    [...clients.entries()].some(([cid, c]) => cid !== id && c.name && c.name.toLowerCase() === n.toLowerCase());
  while (taken()) n = `${base} ${i++}`;
  return n;
}

function broadcastUsers() {
  const users = [...clients.entries()]
    .filter(([, c]) => c.name)
    .map(([id, c]) => ({ id, name: c.name }));
  for (const c of clients.values()) if (c.name) send(c.ws, { type: 'users', users });
}

wss.on('connection', (ws) => {
  const id = String(nextId++);
  clients.set(id, { ws, name: null });
  send(ws, { type: 'welcome', id });

  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    const me = clients.get(id);
    if (!me) return;

    if (m.type === 'join') {
      const base = String(m.name || 'Guest').trim().slice(0, 24) || 'Guest';
      me.name = uniqueName(base, id);
      send(ws, { type: 'joined', name: me.name });
      broadcastUsers();
    } else if (!me.name) {
      return; // must join first
    } else if (m.type === 'chat') {
      const text = String(m.text || '').slice(0, 2000);
      if (!text) return;
      const msg = { type: 'chat', from: id, name: me.name, text, to: m.to, time: Date.now() };
      if (m.to === 'all') {
        for (const [cid, c] of clients) if (cid !== id && c.name) send(c.ws, msg);
      } else if (clients.has(m.to)) {
        send(clients.get(m.to).ws, msg);
      }
    } else if (m.type === 'file') {
      const f = files.get(String(m.fileId));
      if (!f || f.owner !== id) return; // only files this person uploaded
      const msg = { type: 'file', from: id, name: me.name, to: m.to, time: Date.now(), file: { id: f.id, name: f.name, size: f.size } };
      if (m.to === 'all') {
        for (const [cid, c] of clients) if (cid !== id && c.name) send(c.ws, msg);
      } else if (clients.has(m.to)) {
        send(clients.get(m.to).ws, msg);
      }
    } else if (m.type === 'signal') {
      const target = clients.get(m.to);
      if (target) send(target.ws, { type: 'signal', from: id, name: me.name, data: m.data });
    }
  });

  ws.on('close', () => {
    clients.delete(id);
    broadcastUsers();
  });
});

// ---------- start ----------
function listen(server, port, label) {
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\nPort ${port} (${label}) is already in use. Try: PORT=4000 npm start\n`);
    } else {
      console.error(`\n${label} server error:`, err.message, '\n');
    }
    process.exit(1);
  });
  server.listen(port, '0.0.0.0');
}

listen(httpsServer, HTTPS_PORT, 'HTTPS');
listen(httpServer, HTTP_PORT, 'HTTP');

httpsServer.on('listening', () => {
  const ips = lanIPs();
  console.log('\nLAN Chat is running.\n');
  console.log('On this computer:');
  console.log(`  https://localhost:${HTTPS_PORT}\n`);
  if (ips.length === 0) {
    console.log('No Wi-Fi/LAN address found. Connect to your Wi-Fi and restart.\n');
    return;
  }
  console.log('On your phone (same Wi-Fi), open ONE of these:');
  for (const { name, address } of ips) {
    console.log(`  https://${address}:${HTTPS_PORT}   (voice + text)   [${name}]`);
    console.log(`  http://${address}:${HTTP_PORT}    (text only)`);
  }
  console.log('\nPhone cannot open it? Test this first (should say OK):');
  console.log(`  http://${ips[0].address}:${HTTP_PORT}/ping`);
  console.log(`If that fails, allow the ports in the firewall:`);
  console.log(`  sudo ufw allow ${HTTPS_PORT}/tcp && sudo ufw allow ${HTTP_PORT}/tcp\n`);
  if (qr) {
    console.log(`Scan with your phone camera (opens https://${ips[0].address}:${HTTPS_PORT}):`);
    qr.generate(`https://${ips[0].address}:${HTTPS_PORT}`, { small: true });
  }
  console.log('\n(Browser warns about the certificate: choose Advanced -> Proceed.)\n');
});
